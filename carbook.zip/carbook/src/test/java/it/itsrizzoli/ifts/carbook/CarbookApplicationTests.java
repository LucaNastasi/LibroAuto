package it.itsrizzoli.ifts.carbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
