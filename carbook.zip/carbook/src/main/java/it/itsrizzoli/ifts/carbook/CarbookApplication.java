package it.itsrizzoli.ifts.carbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarbookApplication.class, args);
	}

}
