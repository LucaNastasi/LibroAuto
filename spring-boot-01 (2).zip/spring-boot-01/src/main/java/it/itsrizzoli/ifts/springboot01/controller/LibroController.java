package it.itsrizzoli.ifts.springboot01.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import it.itsrizzoli.ifts.springboot01.model.Libro;
import it.itsrizzoli.ifts.springboot01.repository.LibroRepository;

@RestController
public class LibroController {
	
	//classe in grado di lavorare in HTTP
	//serve la LibroRepository creatasi prima
	
	@Autowired
	private LibroRepository repository;
	
	@GetMapping("/libri")
	public List<Libro> all() {
		return repository.findAll();
	}
}
